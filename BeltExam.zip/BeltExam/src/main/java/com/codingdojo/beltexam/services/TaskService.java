package com.codingdojo.beltexam.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codingdojo.beltexam.models.Task;
import com.codingdojo.beltexam.models.User;
import com.codingdojo.beltexam.repositories.TaskRepo;
import com.codingdojo.beltexam.repositories.UserRepo;


@Service
public class TaskService {
	@Autowired
    private TaskRepo taskRepo;
	@Autowired
    private UserRepo userRepo;
	
	
	
    public Task newTask(Task task) {
		return taskRepo.save(task);
	}
    
    public Task save(Task b) {
    	return taskRepo.save(b);
    }
    
    public List<Task> allTasks(){
		return taskRepo.findAll();
	}
    public List<User> allUsers(){
		return userRepo.findAll();
	}
    
    
    public Task findTask(Long id) {
		Optional<Task> mytask = taskRepo.findById(id);
		if (mytask.isPresent()) {
			return mytask.get();
		}else {
			System.out.println("no task you are looking for");
			return null;
		}
	}
    
    public User findUser(Long id) {
        Optional<User> optionalUser = userRepo.findById(id);
        if(optionalUser.isPresent()) {
            return optionalUser.get();
        } else {
            return null;
        }
    }
    
    public void deleteTask(Long myId) {
		taskRepo.deleteById(myId);
	}
    
    public Task updateTask(Task myTask) {
		return taskRepo.save(myTask);
	}
    
}

